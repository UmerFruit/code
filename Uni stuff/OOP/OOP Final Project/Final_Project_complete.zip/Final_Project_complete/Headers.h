/*
 * Headers.h
 *
 *  Created on: 10-May-2023
 *      Author: umerfarooq
 */

#ifndef HEADERS_H_
#define HEADERS_H_
#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <ctime>
using namespace std;
#endif /* HEADERS_H_ */
