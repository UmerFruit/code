/*
 * Records.h
 *
 *  Created on: 14-May-2023
 *      Author: umerfarooq
 */

#ifndef RECORDS_H_
#define RECORDS_H_

class Records
{
protected:
    int index;

public:
    virtual void display() = 0;
};
#endif /* RECORDS_H_ */
