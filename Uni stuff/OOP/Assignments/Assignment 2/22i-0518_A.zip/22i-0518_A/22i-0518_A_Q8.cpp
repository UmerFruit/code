/*
 *  Name : Umer Farooq
 *  Student ID : 22I-0518
 *  Assignment# 2
 */

#include "String.cpp"
int main()
{
    // char o[] = "1928";
    // char p[] = "umer";
    // String s1(p);
    // String s(50);
    // String s4;
    // s.copy(o);

    // cout << s.stoi();
}
