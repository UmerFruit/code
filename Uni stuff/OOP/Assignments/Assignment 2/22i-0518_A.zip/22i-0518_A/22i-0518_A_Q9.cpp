/*
 *  Name : Umer Farooq
 *  Student ID : 22I-0518
 *  Assignment# 2
 */

#include "Integer.cpp"
int main()
{
    // Integer i;
    // Integer j(6);
    // i.set(55);
    // cout << i.toOctString(52);
}
