/*
 *  Name : Umer Farooq
 *  Student ID : 22I-0518
 *  Assignment# 2
 */

#include "Array.cpp"
int main()
{
    // srand(time(0));
    // int *arr = new int[10];
    // for (int i = 0; i < 10; i++)
    // {
    //     arr[i]= rand() % 10;
    // }
    // Array  a(arr,10);
    // Array a2(a);

    // a.display();
    // cout<<a.insert(9,999)<<endl;
    // a.display();
}
